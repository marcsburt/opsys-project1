#include <stdio.h>
int main()
{
  printf("Hello, from Marc Burt! \n");
  return 0;
}